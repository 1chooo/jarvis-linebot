"""Google Lens API Toolkit."""

from langchain.tools.google_lens.tool import GoogleLensQueryRun

__all__ = ["GoogleLensQueryRun"]
