"""Google Trends API Toolkit."""

from langchain.tools.google_trends.tool import GoogleTrendsQueryRun

__all__ = ["GoogleTrendsQueryRun"]
