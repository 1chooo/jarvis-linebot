# flake8: noqa

# import apis into api package
from linebot.v3.webhooks.api.dummy import Dummy


# Async version
from linebot.v3.webhooks.api.async_dummy import AsyncDummy

